var cameraReady = false;

function document_deviceready()
{
    console.info("Device is ready");
    cameraReady = true;
}

function CapturePhoto_click()
{
    if (cameraReady)
    {
        capturePhoto();
    }
    else
    {
        alert("Camera is not ready");
    }
}

function CapturePhotoEdit_click()
{
    if (cameraReady)
    {
        capturePhotoEdit();
    }
    else
    {
        alert("Camera is not ready");
    }
}

function RatingsFields_click()
{
    if (this.checked)
    {
        $("#RatingsFields").slideDown();
    }
    else
    {
        $("#RatingsFields").slideUp();
    }
}

function EditRatingsFields_click()
{
    if (this.checked)
    {
        $("#EditRatingsFields").slideDown();
    }
    else
    {
        $("#EditRatingsFields").slideUp();
    }
}

function SaveDefUser_click()
{
    if (doValidate_DefaultUser())
    {
        localStorage.setItem("DefaultUser", $("#DefaultUser").val());
        $("#MyName").val(localStorage.getItem("DefaultUser")).attr('readonly', true);
        alert("Default user saved");
    }
}

function AddFeedback_click()
{
    AddFeedback();
}

function CancelButton_Click()
{
    alert("Nothing has been changed");
    $(location).prop('href', "#HomePage");
}

function UpdateFeedback_click()
{
    UpdateFeedback();
}

function DeleteFeedback_click()
{
    DeleteFeedback();
}

function SendSuggestions_click()
{
    AddSuggestions();
}

function TypesDropdown_show()
{
    TypesDropdown();
}

// Commenting out for possible future use
//
// function ClearDatabase_click()
// {
//     ClearDatabase();
// }

function ViewFeedbackPage_show()
{
    console.info("Showing all reviews...");
    GetReviews();
}

function EditFeedbackPage_show()
{
    console.info("Editing feedback");
    ShowCurrentReview();
}

function initDB()
{
    try
    {
        console.info("Creating database...");
        DB.CreateDatabase();
        if (db)
        {
            console.info("Creating tables ...");
            DB.CreateTables();
        }
    }
    catch (e)
    {
        console.error("Error: (Fatal) Error in initDB, can not proceed");
    }
}

function init()
{
    $("#Save").on("click", AddFeedback_click);
    $("#Ratings").on("click", RatingsFields_click);
    $("#EditRatings").on("click", EditRatingsFields_click);

    $("#ViewFeedbackPage").on("pageshow", ViewFeedbackPage_show);
    $("#EditFeedbackPage").on("pageshow", EditFeedbackPage_show);
    $("#SuggestionsPage").on("pageshow", TypesDropdown_show);

    $("#Cancel").on("click", CancelButton_Click);
    $("#Update").on("click", UpdateFeedback_click);
    $("#Delete").on("click", DeleteFeedback_click);
    $("#SugSend").on("click", SendSuggestions_click);

    $("#SaveDef").on("click", SaveDefUser_click);

    // Commenting out for possible future use
    //
    // $("#ClearDB").on("click", ClearDatabase_click);

    $(document).on("deviceready", document_deviceready);
    $("#CapturePhoto").on("click", CapturePhoto_click);
    $("#CapturePhotoEdit").on("click", CapturePhotoEdit_click);
}

$(document).ready(function ()
{
    init();
    initDB();
});