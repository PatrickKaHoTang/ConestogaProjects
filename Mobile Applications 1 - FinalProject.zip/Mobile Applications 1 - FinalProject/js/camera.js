function capturePhoto()
{
    var options =
    {
        quality: 50,
        destinationType: Camera.DestinationType.FILE_URI,
        sourceType: Camera.PictureSourceType.CAMERA
    };

    function onSuccess(imageURI)
    {
        var image = $("#ImgSnap");
        image.prop("src", imageURI);
    }

    function onFail(message)
    {
        alert("Failed because: " + message);
    }

    navigator.camera.getPicture(onSuccess, onFail, options);
}

function capturePhotoEdit()
{
    var options =
    {
        quality: 50,
        allowEdit: true,
        destinationType: Camera.DestinationType.DATA_URL,
        sourceType: Camera.PictureSourceType.CAMERA
    };

    function onSuccess(imageData)
    {
        var image = document.getElementById('EditImgSnap');
        image.src = "data:image/jpeg;base64," + imageData;
    }

    function onFail(message)
    {
        alert("Failed because: " + message);
    }

    navigator.camera.getPicture(onSuccess, onFail, options);
}