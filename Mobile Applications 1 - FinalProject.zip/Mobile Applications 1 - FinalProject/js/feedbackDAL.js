// Global Variables

var feedbackSql;
var suggestionsSql;
var typeSql;
var options;

var Feedback =
{
    Insert: function (options)
    {
        function txFunction(tx)
        {
            function successfulInsert()
            {
                console.info("Success: Insert successful");
                alert("New feedback added");
            }

            feedbackSql = "INSERT INTO feedback (myName, purchasedFrom, purchasedWhat, price, " +
                          "purchasedDate, receivedDate, comments, hasRating, " +
                          "shipped, delivery, satisfaction) " +
                "VALUES (?, ?, ?, ?, " +
                        "?, ?, ?, ?, " +
                        "?, ?, ?);";
            tx.executeSql(feedbackSql, options, successfulInsert, errorHandler);
        }
        db.transaction(txFunction, errorHandler, successfulTransaction);
    },
    Select: function (options, successSelectOne)
    {
        function txFunction(tx)
        {
            feedbackSql = "SELECT * FROM feedback " +
                "WHERE id=?;";
            tx.executeSql(feedbackSql, options, successSelectOne, errorHandler);
        }
        db.transaction(txFunction, errorHandler, successfulTransaction);
    },
    SelectAll: function (successSelectAll)
    {
        function txFunction(tx)
        {
            feedbackSql = "SELECT * FROM feedback;";
            options = [];
            tx.executeSql(feedbackSql, options, successSelectAll, errorHandler);
        }
        db.transaction(txFunction, errorHandler, successfulTransaction);
    },
    Update: function (options)
    {
        function txFunction(tx)
        {
            function successfulUpdate()
            {
                console.info("Success: Update successful");
                alert("Record updated successfully");
            }

            feedbackSql = "UPDATE feedback " +
                "SET myName=?, purchasedFrom=?, purchasedWhat=?, price=?, " +
                "purchasedDate=?, receivedDate=?, comments=?, hasRating=?, " +
                "shipped=?, delivery=?, satisfaction=? " +
                "WHERE id=?;";
            tx.executeSql(feedbackSql, options, successfulUpdate, errorHandler);
        }
        db.transaction(txFunction, errorHandler, successfulTransaction);
    },
    Delete: function (options)
    {
        function txFunction(tx)
        {
            function successfulDelete()
            {
                console.info("Success: Delete successful");
                alert("Record deleted successfully");
            }

            feedbackSql = "DELETE FROM feedback " +
                "WHERE id=?;";
            tx.executeSql(feedbackSql, options, successfulDelete, errorHandler);
        }
        db.transaction(txFunction, errorHandler, successfulTransaction);
    }
};

var Suggestion =
{
    Insert: function (options)
    {
        function txFunction(tx)
        {
            function successfulInsert()
            {
                console.info("Success: Insert successful");
                alert("New suggestion added");
            }

            suggestionsSql = "INSERT INTO suggestions (sugName, sugEmail, sugType, sugSubject, sugComments) " +
                "VALUES (?, ?, ?, ?, ?)";
            tx.executeSql(suggestionsSql, options, successfulInsert, errorHandler);
        }
        db.transaction(txFunction, errorHandler, successfulTransaction);
    }
};

var Type =
{
    SelectAll: function (successSelectAll)
    {
        function txFunction(tx)
        {
            typeSql = "SELECT * FROM type;";
            options = [];
            tx.executeSql(typeSql, options, successSelectAll, errorHandler);
        }
        db.transaction(txFunction, errorHandler, successfulTransaction);
    }
};