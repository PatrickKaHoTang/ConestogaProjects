function doValidate_AddFeedbackForm()
{
    var form = $("#AddFeedbackForm");
    form.validate
    ({
        rules:
        {
            MyName:
            {
                required: true
            },
            PurchasedFrom:
            {
                required: true
            },
            PurchasedWhat:
            {
                required: true
            },
            Price:
            {
                required: true,
                min: 0,
                priceFormat: true
            },
            PurchasedDate:
            {
                required: true

            },
            ReceivedDate:
            {
                required: true,
            },
            Shipped:
            {
                required: document.getElementById('Ratings').checked,
                range: [0, 5]
            },
            Delivery:
            {
                required: document.getElementById('Ratings').checked,
                range: [0, 5]
            },
            Satisfaction:
            {
                required: document.getElementById('Ratings').checked,
                range: [0, 5]
            }
        },
        messages:
        {
            MyName:
            {
                required: "You must include your name"
            },
            PurchasedFrom:
            {
                required: "You must include who you purchased from"
            },
            PurchasedWhat:
            {
                required: "You must include what you purchased"
            },
            Price:
            {
                required: "You must include a price",
                min: "Cannot use letters and must be greater than 0",
                priceFormat: "Your format must be correct - i.e. 40.90"
            },
            PurchasedDate:
            {
                required: "You must include when you purchased this item"
            },
            ReceivedDate:
            {
                required: "You must enter when you received this item"
            },
            Shipped:
            {
                required: "You must rate how the shipping process was",
                range: "Value must be 0-5"
            },
            Delivery:
            {
                required: "You must rate how the delivery was",
                range: "Value must be 0-5"
            },
            Satisfaction:
            {
                required: "You must rate how satisfied you are with this person",
                range: "Value must be 0-5"
            }
        }
    });

    return form.valid();
}

function doValidate_EditFeedbackForm()
{
    var form = $("#EditFeedbackForm");
    form.validate
    ({
        rules:
        {
            EditMyName:
            {
                required: true
            },
            EditPurchasedFrom:
            {
                required: true
            },
            EditPurchasedWhat:
            {
                required: true
            },
            EditPrice:
            {
                required: true,
                min: 0,
                priceFormat: true
            },
            EditPurchasedDate:
            {
                required: true
            },
            EditReceivedDate:
            {
                required: true
            },
            EditShipped:
            {
                required: document.getElementById('Ratings').checked,
                range: [0, 5]
            },
            EditDelivery:
            {
                required: document.getElementById('Ratings').checked,
                range: [0, 5]
            },
            EditSatisfaction:
            {
                required: document.getElementById('Ratings').checked,
                range: [0, 5]
            }
        },
        messages:
        {
            EditMyName:
            {
                required: "You must include your name"
            },
            EditPurchasedFrom:
            {
                required: "You must include who you purchased from"
            },
            EditPurchasedWhat:
            {
                required: "You must include what you purchased"
            },
            EditPrice:
            {
                required: "You must include a price",
                min: "Cannot use letters and must be greater than 0",
                priceFormat: "Your format must be correct - i.e. 40.90"
            },
            EditPurchasedDate:
            {
                required: "You must include when you purchased this item"
            },
            EditReceivedDate:
            {
                required: "You must enter when you received this item"
            },
            EditShipped:
            {
                required: "You must rate how the shipping process was",
                range: "Value must be 0-5"
            },
            EditDelivery:
            {
                required: "You must rate how the delivery was",
                range: "Value must be 0-5"
            },
            EditSatisfaction:
            {
                required: "You must rate how satisfied you are with this person",
                range: "Value must be 0-5"
            }
        }
    });

    return form.valid();
}

function doValidate_SuggestionsForm()
{
    var form = $("#SuggestionsForm");
    form.validate
    ({
        rules:
        {
            SugName:
            {
                required: true,
                rangelength: [2, 255]
            },
            SugEmail:
            {
                required: true,
                email: true
            }
        },
        messages:
        {
            SugName:
            {
                required: "You must provide your name",
                rangelength: "Must be greater than 2 characters"
            },
            SugEmail:
            {
                required: "You must provide your email address",
                email: "You must have a valid email address"
            }
        }
    });

    return form.valid();
}

function doValidate_DefaultUser()
{
    var form = $("#SaveDefForm");
    form.validate
    ({
        rules:
        {
            DefaultUser:
            {
                required: true,
                rangelength: [2, 255]
            }
        },
        messages:
        {
            DefaultUser:
            {
                required: "You must enter your name",
                rangelength: "Must be greater than 2 characters"
            }
        }
    });

    return form.valid();
}

jQuery.validator.addMethod("priceFormat",
    function (value, element)
    {
        var regex = /^\$?(?!0.00)(([0-9]{1,3},([0-9]{9},)*)[0-9]{3}|[0-9]{1,3})(\.[0-9]{2})?$/;
        return this.optional(element) || regex.test(value);
    }, "Must use the correct format");