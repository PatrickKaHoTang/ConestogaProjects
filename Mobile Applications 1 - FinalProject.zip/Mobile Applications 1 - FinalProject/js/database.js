// Global Variables

var db;
var suggestionsSql;
var typeSql;
var feedbackSql;

function errorHandler(tx, error)
{
    console.error("SQL error: " + tx + " (" + error.code + ") -- " + error.message);
}

function successfulTransaction()
{
    console.info("Success: Transaction is successful");
}

var DB =
{
    CreateDatabase: function ()
    {
        function dbCreateSuccess()
        {
            console.info("Success: Database creation successful");
        }

        var shortName = "CVVG";
        var version = "1.0";
        var displayName = "Database for CVVG app";
        var dbSize = 2 * 1024 * 1024;

        db = openDatabase(shortName, version, displayName, dbSize, dbCreateSuccess);
    },
    CreateTables: function (options)
    {
        function txFunction(tx)
        {
            function successfulCreate()
            {
                console.info("Success: Table created successfully");
            }

            typeSql = "DROP TABLE IF EXISTS type;";
            tx.executeSql(typeSql, options, null, errorHandler);

            console.info("Creating table: type");

            typeSql = "CREATE TABLE IF NOT EXISTS type (" +
                      "id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT," +
                      "name VARCHAR(20) NOT NULL);";
            tx.executeSql(typeSql, options, null, errorHandler);

            typeSql = "INSERT INTO type (name)" +
                      "VALUES ('App'), ('Information'), ('Layout'), ('Others');";
            tx.executeSql(typeSql, options, null, errorHandler);

            console.info("Creating table: suggestions");
            suggestionsSql = "CREATE TABLE IF NOT EXISTS suggestions (" +
                             "id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT," +
                             "sugName VARCHAR(50) NOT NULL," +
                             "sugEmail VARCHAR(255) NOT NULL," +
                             "sugType INTEGER NOT NULL," +
                             "sugSubject VARCHAR(255) NULL," +
                             "sugComments TEXT NULL," +
                             "FOREIGN KEY(sugType) REFERENCES type(id));";
            tx.executeSql(suggestionsSql, options, successfulCreate, errorHandler);

            console.info("Creating table: feedback");
            feedbackSql = "CREATE TABLE IF NOT EXISTS feedback (" +
                          "id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT," +
                          "myName VARCHAR(50) NOT NULL," +
                          "purchasedFrom VARCHAR(255) NOT NULL," +
                          "purchasedWhat VARCHAR(255) NOT NULL," +
                          "price VARCHAR(10) NOT NULL," +
                          "purchasedDate DATE NOT NULL," +
                          "receivedDate DATE NOT NULL," +
                          "comments TEXT NULL," +
                          // "capture BLOB," +
                          "hasRating VARCHAR(1) NULL," +
                          "shipped INTEGER NULL," +
                          "delivery INTEGER NULL," +
                          "satisfaction INTEGER NULL);";
            tx.executeSql(feedbackSql, options, successfulCreate, errorHandler);
        }
        db.transaction(txFunction, errorHandler, successfulTransaction);
    }
    // Commenting out for possible future use
    //
    // DropTables: function (options)
    // {
    //     function txFunction(tx)
    //     {
    //         function successfulDrop()
    //         {
    //             console.info("Success: Dropping tables successful");
    //         }
    //
    //         console.info("Dropping table: feedback");
    //         feedbackSql = "DROP TABLE IF EXISTS feedback;";
    //         tx.executeSql(feedbackSql, options, successfulDrop, errorHandler);
    //     }
    //     db.transaction(txFunction, errorHandler, successfulTransaction);
    // }
};

