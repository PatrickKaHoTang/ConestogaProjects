// Global Variables

var myName;
var purchasedFrom;
var purchasedWhat;
var price;
var purchasedDate;
var receivedDate;
var comments;
// var capture;
var hasRating;
var shipped;
var delivery;
var satisfaction;
var row;
var id;

function AddFeedback()
{
    if (doValidate_AddFeedbackForm())
    {
        console.info("Validation is true, ready to insert");

        myName = $("#MyName").val();
        purchasedFrom = $("#PurchasedFrom").val();
        purchasedWhat = $("#PurchasedWhat").val();
        price = $("#Price").val();
        purchasedDate = $("#PurchasedDate").val();
        receivedDate = $("#ReceivedDate").val();
        comments = $("#Comments").val();
        // capture = $("#CapturePhoto").val();
        hasRating = $("#Ratings").prop("checked");

        if (hasRating == true)
        {
            shipped = $("#Shipped").val();
            delivery = $("#Delivery").val();
            satisfaction = $("#Satisfaction").val();
        }
        else
        {
            shipped = "";
            delivery = "";
            satisfaction = "";
        }

        options = [myName, purchasedFrom, purchasedWhat, price,
                   purchasedDate, receivedDate, comments,
                   hasRating, shipped, delivery, satisfaction];

        Feedback.Insert(options);
    }
    else
    {
        console.error("Validation failed");
    }
}

function GetReviews()
{
    function successSelectAll(tx, results)
    {
        var htmlCode = "";

        for (var i = 0; i < results.rows.length; i++)
        {
            row = results.rows[i];

            htmlCode += "<li><a data-role='button' data-row-id=" + row['id'] + " href='#'>" +
                        "<p>To: <b>" + row['myName'] + "</b> --> From: <b>" + row['purchasedFrom'] + "</b></p>" +
                        "<p>Item: " + row['purchasedWhat'] + "</p>" +
                        "<p>Comments: " + row['comments'] + "</p>" +
                        "</a></li>";
        }

        var lv = $("#FeedbackList");
        lv = lv.html(htmlCode);
        lv.listview("refresh");
        $("#FeedbackList a").on("click", clickHandler);

        function clickHandler()
        {
            localStorage.setItem("id", $(this).attr("data-row-id"));
            $(location).prop('href', "#EditFeedbackPage");
        }
    }
    Feedback.SelectAll(successSelectAll);
}

function ShowCurrentReview()
{
    id = localStorage.getItem("id");
    options = [id];

    function successSelectOne(tx, results)
    {
        row = results.rows[0];

        $("#EditMyName").val(row['myName']);
        $("#EditPurchasedFrom").val(row['purchasedFrom']);
        $("#EditPurchasedWhat").val(row['purchasedWhat']);
        $("#EditPrice").val(row['price']);
        $("#EditPurchasedDate").val(row['purchasedDate']);
        $("#EditReceivedDate").val(row['receivedDate']);
        $("#EditComments").val(row['comments']);
        // $("#EditCapturePhoto").val(row['capture']);
        $("#EditRatings").prop("checked");

        if (hasRating == true)
        {
            $("#EditRatings").prop("checked", true);
            $("#EditRatingsFields").slideDown();
            $("#EditShipped").val(row['shipped']);
            $("#EditDelivery").val(row['delivery']);
            $("#EditSatisfaction").val(row['satisfaction']);
        }
        else
        {
            $("#EditRatings").prop("checked", false);
            $("#EditRatingsFields").slideUp();
            $("#EditShipped").val(row['shipped']);
            $("#EditDelivery").val(row['delivery']);
            $("#EditSatisfaction").val(row['satisfaction']);
        }

        $("#EditForm :checkbox").checkboxradio("refresh");
    }
    Feedback.Select(options, successSelectOne);
}

function UpdateFeedback()
{
    if (doValidate_EditFeedbackForm())
    {
        id = localStorage.getItem("id");
        myName = $("#EditMyName").val();
        purchasedFrom = $("#EditPurchasedFrom").val();
        purchasedWhat = $("#EditPurchasedWhat").val();
        price = $("#EditPrice").val();
        purchasedDate = $("#EditPurchasedDate").val();
        receivedDate = $("#EditReceivedDate").val();
        comments = $("#EditComments").val();
        // capture = $("#EditCapturePhoto").val();
        hasRating = $("#Ratings").prop("checked");

        if (hasRating == true)
        {
            shipped = $("#EditShipped").val();
            delivery = $("#EditDelivery").val();
            satisfaction = $("#EditSatisfaction").val();
        }
        else
        {
            shipped = "";
            delivery = "";
            satisfaction = "";
        }

        options = [myName, purchasedFrom, purchasedWhat, price,
                   purchasedDate, receivedDate, comments, hasRating,
                   shipped, delivery, satisfaction, id];

        Feedback.Update(options);
    }
    else
    {
        console.info("Unable to update");
    }
}

function AddSuggestions()
{
    if (doValidate_SuggestionsForm())
    {
        var sugName = $("#SugName").val();
        var sugEmail = $("#SugEmail").val();
        var sugType = $("#SugType").val();
        var sugSubject = $("#SugSubject").val();
        var sugComments = $("#SugComments").val();

        options = [sugName, sugEmail, sugType, sugSubject, sugComments];

        Suggestion.Insert(options);
    }
    else
    {
        console.info("Unable to add suggestion");
    }
}

function TypesDropdown()
{
    function successSelectAll(tx, results)
    {
        var htmlCode = "";

        for (var i = 0; i < results.rows.length; i++)
        {
            row = results.rows[i];

            htmlCode += "<option value='" + row['id'] + "'>" + row['name'] + "</option>";
        }

        var options;

        options = $("#SugType");
        options = options.html(htmlCode);
        options.select("refresh");
        $("#Suggestions select").on("pageshow", clickHandler);

        function clickHandler()
        {
            localStorage.setItem("id", $(this).attr("value"));
        }
    }
    Type.SelectAll(successSelectAll);
}

function DeleteFeedback()
{
    id = localStorage.getItem("id");
    options = [id];
    Feedback.Delete(options);
    $(location).prop('href', "#ViewFeedbackPage");
}

// Commenting out for possible future use][
//
// function ClearDatabase()
// {
//     var result = confirm("Really want to clear database?");
//
//     try
//     {
//         if (result)
//         {
//             DB.DropTables();
//             alert("Database cleared");
//         }
//     }
//     catch (e)
//     {
//         alert(e);
//     }
// }