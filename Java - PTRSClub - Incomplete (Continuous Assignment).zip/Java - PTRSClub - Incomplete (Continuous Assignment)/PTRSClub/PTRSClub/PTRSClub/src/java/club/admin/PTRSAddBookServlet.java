package club.admin;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import club.business.Book;
import club.data.BookIO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author rsilva6165
 */
public class PTRSAddBookServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, NumberFormatException {
        response.setContentType("text/html;charset=UTF-8");
        
        try {
           Book book = new Book();
           int quantity = 0;
           String url;
           String message = "";
           
           String code = request.getParameter("code");
           String description = request.getParameter("description");

            quantity = Integer.parseInt(request.getParameter("quantity"));    

           
           //validation
           if(code == null || code.isEmpty()){
               message += "Book code is required.";
           }
           
           if(description == null || description.isEmpty() || description.length() < 2){
               message += "<br>Description must have at least 2 characters.";
           }
           
           if(quantity < 1){
               message += "<br>Quantity must be a positive number.";
           }
           
            book.setCode(code);
            book.setDescription(description);
            book.setQuantity(quantity);
           
           if(message.length() > 0){//we got errors.
               request.setAttribute("message", message);
               request.setAttribute("book", book);
               url = "/PTRSAddBook.jsp";
           }else{
                ServletContext context = getServletContext();
                String path = context.getRealPath("/WEB-INF/books.txt");
                BookIO.insert(book, path);
                url = "/PTRSDisplayBooks";
           }
           
           getServletContext().getRequestDispatcher(url)
                    .forward(request,response);
           
        } finally {
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
